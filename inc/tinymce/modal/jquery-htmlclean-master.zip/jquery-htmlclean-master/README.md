jQuery HTML Clean
=================

Shim repository for the [jQuery HTML Clean plugin](https://code.google.com/p/jquery-clean/).

Package Managers
----------------

* [Bower](http://twitter.github.com/bower/): `jquery-htmlclean`
* [Composer](https://packagist.org/packages/components/jquery-htmlclean): `components/jquery-htmlclean`
